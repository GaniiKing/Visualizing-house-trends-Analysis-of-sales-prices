# Visualizing-Housing-Market-Trends-An-Analysis-of-Sale-Prices-and-Features-using-Tableau
The "Visualizing Housing Market Trends" project aims to analyze and present key housing market insights using Tableau for data visualization and Flask for web application deployment. The project focuses on understanding how different factors influence sale prices and other real estate trends.
